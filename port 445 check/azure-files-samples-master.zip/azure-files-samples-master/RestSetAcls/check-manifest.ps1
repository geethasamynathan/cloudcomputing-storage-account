Test-ModuleManifest -Path $PSScriptRoot\RestSetAcls\RestSetAcls.psd1
